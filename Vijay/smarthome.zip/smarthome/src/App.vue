<template>
  <div id="app">
    <Navbar />
    <LeftSideBar />
    <div class="container-fluid page-content">
      <router-view/>
    </div>
  </div>
</template>

<script>
import Navbar from '@/components/Navbar.vue'
import LeftSideBar from '@/components/LeftSideBar.vue'

export default {
  components: {
    Navbar,
    LeftSideBar
  }  
}
</script>

