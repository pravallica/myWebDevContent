<template>
  <div class="left-side-bar">
    <div class="profile">
      <div class="profile-avatar">
        <img alt="Vue logo" class="" src="@/assets/images/profile-image.png">
      </div>
      <div class="profile-details">
        <h3 class="user-name">My Home</h3>
        <div class="address">
          1200 Fox Rd #6, Maryville, Mo
        </div>
      </div>
    </div>

    <div class="menu-links">
      <ul class="list-unstyled">
        <li class="menu-link-item">
          <router-link to="/">
            <div class="float-left menu-link-icon">
              <i class="fas fa-home"></i>
            </div>
            <div class="menu-link-text">
              overview
            </div>
          </router-link>
        </li>
        <li class="menu-link-item">
          <router-link to="about">
            <div class="float-left menu-link-icon">
              <i class="fas fa-laptop"></i>
            </div>
            <div class="menu-link-text">
              Devices
            </div>
          </router-link>
        </li>
        <li class="menu-link-item">
          <a href="#">
            <div class="float-left menu-link-icon">
              <i class="fas fa-chart-bar"></i>
            </div>
            <div class="menu-link-text">
              Analytics
            </div>
          </a>
        </li>
        <li class="menu-link-item">
          <a href="#">
            <div class="float-left menu-link-icon">
              <i class="fas fa-align-left"></i>
            </div>
            <div class="menu-link-text">
              Rules
            </div>
          </a>
        </li>
        <li class="menu-link-item">
          <a href="#">
            <div class="float-left menu-link-icon">
              <i class="fas fa-images"></i>
            </div>
            <div class="menu-link-text">
              Gallery
            </div>
          </a>
        </li>
        <li class="menu-link-item">
          <a href="#">
            <div class="float-left menu-link-icon">
              <i class="fas fa-redo"></i>
            </div>
            <div class="menu-link-text">
              History
            </div>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>

<style lang="less">
.left-side-bar {
  background-color: #242e42;
  width: 240px;
  float: left;
  color: white;
  height: 100%;

  .profile {
    text-align: center;
    .profile-avatar {
      width: 90px;
      margin: 0px auto;
      margin-top: 35px;
      img {
        width: 90px;
        height: 90px;
        border-radius: 50%;
      }
    }

    .profile-details {
      color: #98A7B9;
      .user-name {
        font-size: 17px;
        font-weight: lighter;
        line-height: 20px;
        margin-top: 8px;
        margin-bottom: 0px;
      }
      .address {
        font-size: 12px;
        font-weight: normal;
        line-height: 14px;
        margin-top: 3px;
      }
    }
  }
  
  .menu-links {
    width: 175px;
    margin-top: 25px;
    .menu-link-item {
      width: 175px;
      border-left: 7px solid #242e42 !important;
      margin-bottom: 5px;
      height: 47px;
      border-top-right-radius: 8px;
      border-bottom-right-radius: 8px;

      a {
        color: #98A7B9;
        line-height: 47px;
        font-size: 16px;
        text-transform: capitalize;
        .menu-link-icon {
          padding-left: 28px;
        }
        .menu-link-text {
          padding-left: 20px;
          display: inline-block;
        }
      }

      &:hover {
        border-left: 7px solid #1F8EFA !important;
        background-color: #1A2233;
        a {
          color: white;
        }
      }
    }

  }
}
</style>
