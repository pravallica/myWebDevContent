<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light sh-navbar">
    <a class="navbar-brand" href="#">
      <img alt="Smart Home" src="@/assets/images/logo.png">
    </a>
    <button
      class="navbar-toggler"
      type="button"
      data-toggle="collapse"
      data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="sh-toggle">
      <a href="#" class="sh-toggle-link">
        <i class="fas fa-bars"></i>
      </a>
    </div>
    <div class="collapse navbar-collapse"
      id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto sh-navbar-right">
        <li class="nav-item">
          <a class="nav-link" href="#">
            <i class="fas fa-question-circle"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" @click="add">
            <i class="fas fa-envelope"></i>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#" @click="increment">
            <i class="fas fa-bell"></i>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{ cart.length }}
            <i class="fas fa-caret-down"></i>
          </a>
          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>

import { mapState, mapActions } from 'vuex'

export default {
  name: 'Navbar',
  computed: {
    ...mapState({
      counter: state => state.count,
      cart: state => state.cart
    })
  },
  methods: {
    ...mapActions([
      'increment',
      'addToCart'
    ]),
    add () {
      this.addToCart({
        name: 'iPhone',
        amount: 100
      })
    }
  }
}
</script>

<style lang="less" scoped>
@navbarBorder: #20293C;
@navLinkColor: #657D95;

.sh-navbar {
  background-color: #242e42 !important;
  height: 68px;
  padding: 0px;
  border-bottom: 1px solid @navbarBorder;

  .navbar-brand {
    width: 240px;
    height: 67px;
    border-right: 1px solid @navbarBorder;
    padding-left: 30px;
    padding-top: 10px;
    padding-bottom: 30px;
    margin-right: 0px;
  }

  .sh-toggle {
    width: 64px;
    height: 67px;
    text-align: center;
    border-right: 1px solid @navbarBorder;
    padding-top: 20px;

    .sh-toggle-link {
      color: @navLinkColor;
    }
  }

  .sh-navbar-right {
    margin-right: 40px;
  }

  .nav-link {
    padding: 10px !important;

    &.dropdown-toggle::after {
      content: none
    }
  }

  i {
    color: @navLinkColor;
    font-size: 20px;
  }

  .navbar-nav {
    .nav-item {
      .nav-link {
        color: #CFD7DB;
      }
    }
  }
}
</style>
