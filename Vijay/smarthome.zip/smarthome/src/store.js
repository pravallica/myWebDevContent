import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    count: 100,
    cart: []
  },
  mutations: {
    increment (state) {
      state.count++
    },
    cartadd (state, item) {
      console.log(item)
      state.cart.push(item)
    }
  },
  actions: {
    increment (context) {
      context.commit('increment')
    },
    addToCart (context, item) {
      context.commit('cartadd', item)
    }
  }
})
