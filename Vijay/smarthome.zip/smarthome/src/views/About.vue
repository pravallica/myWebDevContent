<template>
  <div class="">
    <h2 class="page-header">
      Devices
    </h2>

    <div class="card sh-card">
      <div class="card-header">
        This is an about page
      </div>
      <div class="card-body">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga culpa iusto sed quis sint consequuntur a molestias. Dolore vel nulla dolor aliquid itaque exercitationem harum natus facilis, nostrum sit dolorem.
      </div>
    </div>
  </div>
</template>
