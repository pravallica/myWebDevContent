<template>
  <div>
    <h2 class="page-header">
      Overview
    </h2>
    <div class="row">
      <div class="col-md-8">
        <HelloWorld />
      </div>
      <div class="col-md">
        <HelloWorld />
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'home',
  components: {
    HelloWorld
  }
}
</script>

<style lang="less">
</style>
